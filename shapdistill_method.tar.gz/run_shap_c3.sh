#!/usr/bin/env bash
# C3: Conformal Adaptive-K routing on DaliaHAR.
# 3 folds parallel on cuda:0/1/2.
set -uo pipefail

cd "$(dirname "$0")"
PY=/home/egg8711/miniconda3/envs/maestro/bin/python
FUSION_DIR=./model_chkpt/DaliaHAR/multimodal_model/2026-05-14_DaliaHAR_v6_fusion_only_dyna
RESULTS_DIR=./model_chkpt/DaliaHAR/selector/

TAU_LO=${TAU_LO:-0.1}
TAU_HI=${TAU_HI:-0.9}
LAMBDA_Q=${LAMBDA_Q:-1.0}
LAMBDA_KL=${LAMBDA_KL:-0.0}
LAMBDA_CE_SOFT=${LAMBDA_CE_SOFT:-0.0}
RULE=${RULE:-upper}
THR=${THR:-0.0}
NUM_EPOCHS=${NUM_EPOCHS:-30}
TAG=${TAG:-rule${RULE}_thr${THR/./p}}
EXP=${EXP_NAME:-v6_shap_c3_${TAG}}
mkdir -p logs
echo "Running EXP=$EXP  tau_lo=$TAU_LO tau_hi=$TAU_HI  lambda_q=$LAMBDA_Q rule=$RULE thr=$THR"

run_fold () {
  local FOLD="$1"
  local GPU="$2"
  "$PY" script/main_v6_daliahar_selector_finetune_shapley_c3.py \
    --fold="$FOLD" --cuda_pick="cuda:${GPU}" \
    --frozen_ckpt="${FUSION_DIR}/best_model_fold${FOLD}.pth" \
    --shapley_train_npz="${FUSION_DIR}/shapley_train_fold${FOLD}_phi.npz" \
    --target_k=4 --selector_downsample_factor=4 \
    --tau_lo="$TAU_LO" --tau_hi="$TAU_HI" --lambda_q="$LAMBDA_Q" \
    --lambda_kl="$LAMBDA_KL" --lambda_ce_soft="$LAMBDA_CE_SOFT" \
    --c3_select_rule="$RULE" --c3_threshold="$THR" \
    --min_k=1 --max_k=5 \
    --num_epochs="$NUM_EPOCHS" --batch_size=64 \
    --lr=3e-4 --lr_schedule=cosine --lambda_probe=0.05 \
    --exp_name="$EXP" --results_dir="$RESULTS_DIR" \
    > "logs/shap_c3_${EXP}_fold${FOLD}.log" 2>&1
}

run_fold 0 0 &
run_fold 1 1 &
run_fold 2 2 &
wait
echo "All 3 C3 folds finished ($EXP)."
